# 2026-07-08 語音怪聲偵測更新說明

## 更新重點

本次更新修正 `video/44.mp4` 使用 `model/noise.wav` 範本偵測怪聲時，會誤選到 `98.300s ~ 99.050s` 的問題。

修正後，`44.mp4` 會選到：

```text
134.750s ~ 144.750s
template_similarity = 0.9688
```

## 需要同步給組員的檔案

請覆蓋以下檔案：

```text
modules/speech.py
modules/speech_engine.py
model/noise.wav
```

其中 `model/noise.wav` 是怪聲範本音檔，主程式會從這個路徑讀取。

## 程式修改內容

### `modules/speech.py`

- 新增 `EXPECTED_MATCHING_ALGORITHM_VERSION = 14`。
- 讀取 `output/speech_cache.json` 前會檢查快取版本。
- 舊版快取會自動重新分析，避免繼續使用錯誤怪聲時間。
- 主流程呼叫 `speech_engine.py` 時，怪聲範本相似度門檻改為 `0.85`。

### `modules/speech_engine.py`

- `MATCHING_ALGORITHM_VERSION` 升級為 `14`。
- 怪聲範本預設相似度門檻改為 `0.85`。
- 修正外部 `noise.wav` 讀取流程，不再輸出 `output/noise_reference_sample.wav`。
- 若需要轉檔，改用系統暫存 wav，使用後會自動刪除。
- 範本滑窗事件會參與候選選擇，但必須通過 `0.85` 門檻，避免低相似度片段誤判。

## 單獨測試指令

```bash
cd /path/to/project
conda activate integrate_env
python modules/speech_engine.py --video video/44.mp4 --output-dir output --skip-whisper --noise-sample model/noise.wav
```

預期輸出應包含：

```text
怪聲事件：
  - 134.750s ~ 144.750s score=96.932
```

`output/transcript_with_events.txt` 預期應包含：

```text
怪聲樣本相似度門檻：0.85
[02:14 - 02:24] alarm_like_noise score=96.932
樣本相似度：0.9688
判定視窗：134.750s ~ 144.750s
```

## 注意事項

- 不要上傳 `video/`，影片檔太大且可能含個資。
- 不要上傳 `output/`，這是本機自動產生的結果與快取。
- 不要上傳 `__pycache__/`、`.DS_Store`、`.venv/`。
- 如果組員端已經有舊的 `output/speech_cache.json`，請刪除或讓新版程式自動重跑。
